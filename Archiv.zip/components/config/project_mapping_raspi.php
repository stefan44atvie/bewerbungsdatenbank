<?php
// components/config/project_mapping.php

return [
    'Bewerbungsdatenbank' => [
        'dirname' => '/var/www/html/bewerbungsdatenbank',
        'version_table' => 'settings',
        'version_id' => 1,
    ],
];