<?php
// components/config/project_mapping.php

return [
    'Agency 2025' => [
        'dirname' => 'agency',
        'version_table' => 'settings',
        'version_id' => 1,
    ],
];