<?php
return [
    'timezone' => 'Europe/Vienna',
    // Weitere Konfigs:
    // 'db_host' => 'localhost',
    // 'debug' => true,
];