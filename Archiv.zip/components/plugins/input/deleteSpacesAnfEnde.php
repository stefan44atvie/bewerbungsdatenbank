<?php 
    function deleteLeadingAndTrailingWhitespace($mystring) {
        return trim($mystring);
    }
?>