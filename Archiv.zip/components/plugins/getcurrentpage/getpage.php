<?php 
    function getCurrentPage() {
        return basename($_SERVER['SCRIPT_NAME']);
    }
?>